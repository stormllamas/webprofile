======
Boards
======

Polls is a simple Django app that is a platform for
Boards -> topics -> posts. For each Board There is topics and each topic
there are posts. 

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "boards" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'boards',
    ]

2. Include the boards URLconf in your project urls.py like this::

    path('boards/', include('boards.urls')),

3. Run `python manage.py migrate` to create the boards models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a board topic (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/boards/ to participate.

6. Install: pip install django-widget-tweaks

7. INSTALLED_APPS = Add 'widget_tweaks'


=======================================================================================
Try building your package with python setup.py sdist (run from inside django-boards).
=======================================================================================