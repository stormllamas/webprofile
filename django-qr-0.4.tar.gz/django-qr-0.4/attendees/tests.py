from django.test import TestCase
from django.urls import reverse, resolve
from django.utils import timezone

from PIL import Image
from django.utils.six import BytesIO

from .models import Attendee
from .views import index, payments, qrgenerated, attendee_upload, qrscanner, details
from .forms import PaymentsForm, CSVForm

import datetime
import simplejson as json


# Create your tests here.
def create_image(storage, filename, size=(100, 100), image_mode='RGB', image_format='PNG'):
    """
    Generate a test image, returning the filename that it was saved as.

    If ``storage`` is ``None``, the BytesIO containing the image data
    will be passed instead.
    """
    data = BytesIO()
    Image.new(image_mode, size).save(data, image_format)
    data.seek(0)
    if not storage:
        return data
    image_file = ContentFile(data.read())
    return storage.save(filename, image_file)

def create_attendee(first_name, last_name, days):
    """
    Create a attendee with the given `first_name and last_name` and timestamp is the
    given number of `days` offset to now (negative for attendees timestamped
    in the past, positive for attendees that have yet to be timestamped).
    """
    time = timezone.now() + datetime.timedelta(days=days)
    return Attendee.objects.create(first_name=first_name, last_name=last_name, timestamp=time)
    

class AttendeesIndexViewTest(TestCase):
    def test_index_url_resolves_index_view(self):
        view = resolve('/attendees/')
        self.assertEqual(view.func, IndexListView)

    def test_navbar_breadcrumb_links_exists(self):
        response = self.client.get(reverse('attendees:index'))
        self.assertContains(response, 'Storm Cards')
        self.assertContains(response, 'Attendees')

    def test_action_links_exist(self):
        response = self.client.get(reverse('attendees:index'))
        index_url = reverse('attendees:index')
        qrpayments_url = reverse('attendees:payments')
        qrgenerated_url = reverse('attendees:qrgenerated')
        attendee_upload_url = reverse('attendees:attendee_upload')
        qrscanner_url = reverse('attendees:qrscanner')
        self.assertContains(response,'href="{0}"'.format(index_url))
        self.assertContains(response,'href="{0}"'.format(qrpayments_url))
        self.assertContains(response,'href="{0}"'.format(qrgenerated_url))
        self.assertContains(response,'href="{0}"'.format(attendee_upload_url))
        self.assertContains(response,'href="{0}"'.format(qrscanner_url))

    def test_no_attendees(self):
        response = self.client.get(reverse('attendees:index'))
        self.assertContains(response, 'No Attendees Registered')
        self.assertQuerysetEqual(response.context['attendees'], [])
        
    def test_has_attendees(self):
        create_attendee(first_name='John', last_name='Doe', days=0)
        response = self.client.get(reverse('attendees:index'))
        attendee = Attendee.objects.get(pk=1)
        self.assertContains(response, 'Doe, John')
        self.assertContains(response, 'Absent')
        self.assertContains(response, '500')

class AttendeesPaymenstsViewTest(TestCase):
    def test_payments_url_resolves_payments_view(self):
        view = resolve('/attendees/payments/')
        self.assertEqual(view.func, payments)

    def test_navbar_breadcrumb_links_exists(self):
        response = self.client.get(reverse('attendees:payments'))
        self.assertContains(response, 'Storm Cards')
        self.assertContains(response, 'Attendees')
        self.assertContains(response, 'QR Payments')

    def test_payments_to_index_link_exist(self):
        response = self.client.get(reverse('attendees:payments'))
        index_url = reverse('attendees:index')
        self.assertContains(response,'href="{0}"'.format(index_url))

    def test_csrf(self):
        url = reverse('attendees:payments')
        response = self.client.get(url)
        self.assertContains(response, 'csrfmiddlewaretoken')

    def test_contains_form(self):
        url = reverse('attendees:payments')
        response = self.client.get(url)
        form = response.context.get('form')
        self.assertIsInstance(form, PaymentsForm)

    def test_payments_invalid_post_data_empty_fields(self):
        url = reverse('attendees:payments')
        data = {
            'amount': ''
        }
        response = self.client.post(url, data)
        form = response.context.get('form')
        self.assertEquals(response.status_code, 200)
        self.assertTrue(form.errors)

class AttendeesUploadViewTest(TestCase):
    def test_upload_url_resolves_payments_view(self):
        view = resolve('/attendees/upload-csv/')
        self.assertEqual(view.func, attendee_upload)

    def test_navbar_breadcrumb_links_exists(self):
        response = self.client.get(reverse('attendees:attendee_upload'))
        self.assertContains(response, 'Storm Cards')
        self.assertContains(response, 'Attendees')
        self.assertContains(response, 'Upload Contacts')

    def test_payments_to_index_link_exist(self):
        response = self.client.get(reverse('attendees:attendee_upload'))
        index_url = reverse('attendees:index')
        self.assertContains(response,'href="{0}"'.format(index_url))

    def test_csrf(self):
        url = reverse('attendees:attendee_upload')
        response = self.client.get(url)
        self.assertContains(response, 'csrfmiddlewaretoken')

    def test_contains_form(self):
        url = reverse('attendees:attendee_upload')
        response = self.client.get(url)
        form = response.context.get('form')
        self.assertIsInstance(form, CSVForm)

    def test_payments_valid_post_data(self):
        url = reverse('attendees:attendee_upload')
        avatar = create_image(None, 'avatar.csv')
        data = {
            'file': avatar
        }
        response = self.client.post(url, data)
        form = response.context.get('form')
        self.assertEquals(response.status_code, 200)
        self.assertFalse(form.errors)

    def test_payments_invalid_post_data(self):
        url = reverse('attendees:attendee_upload')
        avatar = create_image(None, 'avatar.png')
        data = {
            'file': avatar
        }
        response = self.client.post(url, data)
        form = response.context.get('form')
        self.assertEquals(response.status_code, 200)

    def test_payments_invalid_post_data_empty_fields(self):
        url = reverse('attendees:attendee_upload')
        data = {
            'file': ''
        }
        response = self.client.post(url, data)
        form = response.context.get('form')
        self.assertEquals(response.status_code, 200)

class AttendeesDetailsViewTest(TestCase):
    def test_details_url_resolves_payments_view(self):
        view = resolve('/attendees/details/1')
        self.assertEqual(view.func, details)

    def test_navbar_breadcrumb_links_exists(self):
        create_attendee(first_name='John', last_name='Doe', days=0)
        url = reverse('attendees:details', kwargs={'attendee_id':1})
        response = self.client.get(url)
        attendee = Attendee.objects.get(pk=1)
        self.assertContains(response, 'Storm Cards')
        self.assertContains(response, 'Attendees')
        self.assertContains(response, 'John Doe')

    def test_details_to_index_link_exist(self):
        create_attendee(first_name='John', last_name='Doe', days=0)
        url = reverse('attendees:details', kwargs={'attendee_id':1})
        response = self.client.get(url)
        index_url = reverse('attendees:index')
        self.assertContains(response,'href="{0}"'.format(index_url))

    def test_details_new_attendee(self):
        create_attendee(first_name='John', last_name='Doe', days=0)
        self.assertTrue(Attendee.objects.exists())

    def test_details_new_attendee_no_data(self):
        self.assertFalse(Attendee.objects.exists())
        
    def test_details_view_success_status_code(self):
        create_attendee(first_name='John', last_name='Doe', days=0)
        url = reverse('attendees:details', kwargs={'attendee_id':1})
        response = self.client.get(url)
        self.assertEquals(response.status_code, 200)

    def test_details_view_not_found_status_code(self):
        create_attendee(first_name='John', last_name='Doe', days=0)
        url = reverse('attendees:details', kwargs={'attendee_id':99})
        response = self.client.get(url)
        self.assertEquals(response.status_code, 404)
