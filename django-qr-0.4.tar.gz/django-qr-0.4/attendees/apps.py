from django.apps import AppConfig


class AttendeesConfig(AppConfig):
    name = 'attendees'
