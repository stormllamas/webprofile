﻿======================
Django - Authorization
======================

This is a Django account authorization app that includes:
-signup
-login
-logout
-account settings editing
-reset password (initiate a change password, reset password, 

for detailed functions of this app go the "docs" directory


Quick start
------------

1. INSTALLED_APPS - Add accounts.apps.AccountsConfig to your settings' installed apps.
2. EMAIL_BACKEND - Add "EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'" to your settings.
3. LOGOUT_REDIRECT_URL = '/'
4. LOGIN_REDIRECT_URL = '/'
5. LOGIN_URL = 'login'
6. Install: pip install django-widget-tweaks
7. INSTALLED_APPS = Add 'widget_tweaks'

8. Add the imports and the URL confs below:

from django.contrib.auth import views as auth_views
from accounts import views as accounts_views

    path('signup/', accounts_views.signup, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('settings/account/', accounts_views.UserUpdateView.as_view(), name='my_account'),
    
    path('reset/',
        auth_views.PasswordResetView.as_view(
        template_name='accounts/password_reset.html',
        email_template_name='accounts/password_reset_email.html',
        subject_template_name='accounts/password_reset_subject.txt'
        ),
        name='password_reset'),
    path('reset/done/',
        auth_views.PasswordResetDoneView.as_view(template_name='accounts/password_reset_done.html'),
        name='password_reset_done'),
    path('reset/<uidb64>/<token>/',
        auth_views.PasswordResetConfirmView.as_view(template_name='accounts/password_reset_confirm.html'),
        name='password_reset_confirm'),
    path('reset/complete/',
        auth_views.PasswordResetCompleteView.as_view(template_name='accounts/password_reset_complete.html'),
        name='password_reset_complete'),

    path('settings/password/', auth_views.PasswordChangeView.as_view(template_name='accounts/password_change.html'),
        name='password_change'),
    path('settings/password/done/', auth_views.PasswordChangeDoneView.as_view(template_name='accounts/password_change_done.html'),
        name='password_change_done'),

=======================================================================================
Try building your package with python setup.py sdist (run from inside django-accounts).
=======================================================================================