from django import forms
from .models import Contact
from .choices import bedroom_choices, price_choices, state_choices

class SearchForm(forms.Form):
    bc = bedroom_choices.items()
    pc = price_choices.items()
    sc = state_choices.items()


    keywords = forms.CharField(
        label = 'Property',
        widget=forms.TextInput(
            attrs={'rows':1, 'placeholder': 'Keyword (Pool, Garage, etc)'}
        ),
        max_length=50,
        required = False,)
    city = forms.CharField(
        label = 'Property',
        widget=forms.TextInput(
            attrs={'rows':1, 'placeholder': 'City'}
        ),
        max_length=50,
        required = False,)
    state = forms.ChoiceField(
        choices=sc,
        widget=forms.Select(
            attrs={'rows':1, 'placeholder': 'State (All)'}
        ),
        initial = '',
        required = False,)
    bedrooms = forms.ChoiceField(
        choices=bc,
        widget=forms.Select(
            attrs={'rows':1, 'placeholder': 'Bedrooms (All)'}
        ),
        required = False,)
    max_price = forms.ChoiceField(
        choices=pc,
        widget=forms.Select(
            attrs={'rows':1, 'placeholder': 'Max Price (Any)'}
        ),
        required = False,)

class ContactForm(forms.ModelForm):
    listing = forms.CharField(
        label = 'Property',
        widget=forms.TextInput(
            attrs={'rows':1}
        ),
        max_length=50,
        required = True,
        )

    name = forms.CharField(
        widget=forms.TextInput(
            attrs={'rows':1}
        ),
        max_length=50,
        required = True,
        )

    email = forms.EmailField(
        widget=forms.TextInput(
            attrs={'rows':1}
        ),
        max_length=50,
        required = True,
        )

    phone = forms.CharField(
        widget=forms.TextInput(
            attrs={'rows':1}
        ),
        max_length=50,
        required = False,
        help_text='(optional)'
        )

    message = forms.CharField(
        widget=forms.Textarea(
            attrs={'rows':2, 'placeholder': 'What is on your mind?'}
        ),
        max_length=4000,
        help_text='(optional) 4000 characters allowed',
        required = False,
        )

    class Meta:
        model = Contact
        fields = ['listing', 'name', 'email', 'phone', 'message']


# class Contact(models.Model):
#     user_id = models.IntegerField(blank=True)
#     listing_id = models.IntegerField()
#     listing = models.CharField(max_length=200)
#     name = models.CharField(max_length=200)
#     email = models.CharField(max_length=100)
#     phone = models.CharField(max_length=100, blank=True)
#     message = models.TextField(blank=True)
#     contact_date = models.DateTimeField(default=datetime.now, blank=True)