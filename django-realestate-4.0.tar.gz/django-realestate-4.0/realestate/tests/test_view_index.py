from django.test import TestCase
from django.urls import reverse, resolve
from django.utils import timezone
import datetime

from ..models import Realtor, Listing
from ..views import index
from ..forms import SearchForm, ContactForm

from django.contrib.auth.models import User

from django.test import override_settings
from PIL import Image
from io import BytesIO
from django.core.files import File
import tempfile

def get_image_file(name='test.png', ext='png', size=(50, 50), color=(256, 0, 0)):
    file_obj = BytesIO()
    image = Image.new("RGB", size=size, color=color)
    image.save(file_obj, ext)
    file_obj.seek(0)
    return File(file_obj, name=name)

class RealestateIndexViewTest(TestCase):
    def setUp(self):
        url = reverse('btre:index')
        self.response = self.client.get(url)

    def test_index_status_code(self):
        self.assertEquals(self.response.status_code, 200)

    def test_index_url_resolves_index_view(self):
        view = resolve('/realestate/')
        self.assertEqual(view.func, index)

    def test_csrf(self):
        self.assertContains(self.response, 'csrfmiddlewaretoken')

    def test_contains_search_form(self):
        form = self.response.context.get('form')
        self.assertIsInstance(form, SearchForm)

    def test_search_form_inputs(self):
        self.assertContains(self.response, '<input', 3)
        self.assertContains(self.response, '<select', 3)

    def test_has_listings(self):
        realtor = Realtor.objects.create(name='sample_realtor', photo=get_image_file())
        listing = Listing.objects.create(
            realtor=Realtor.objects.get(pk=realtor.id),
            title='listing_sample', address='sample', city='sample', state='sample', zipcode='1234', price='555555', bedrooms='1', bathrooms='1', garage='1', sqft='123', lot_size='123',
            photo_main=get_image_file(),
            photo_1=get_image_file(),
            photo_2=get_image_file(),
            photo_3=get_image_file(),
            photo_4=get_image_file(),
            photo_5=get_image_file(),
            photo_6=get_image_file()
            )
        btre_index_url = reverse('btre:index')
        listing_url = reverse('btre:listing', kwargs={'listing_id':listing.id})
        response = self.client.get(btre_index_url)
        self.assertTrue(Realtor.objects.exists())
        self.assertTrue(Listing.objects.exists())
        self.assertQuerysetEqual(response.context['listings'], ['<Listing: listing_sample>'])
        self.assertContains(response, 'href="{0}"'.format(listing_url))
        self.assertContains(response, 'listing_sample')

    def test_no_listings(self):
        self.assertContains(self.response, 'No Listings Available')
        self.assertQuerysetEqual(self.response.context['listings'], [])


class RealestateNavbarTopbarTest(TestCase):
    def setUp(self):
        url = reverse('btre:index')
        self.response = self.client.get(url)

    def test_topbar_navbar_links_exists(self):
        index_url = reverse('index')
        btre_index_url = reverse('btre:index')
        about_url = reverse('btre:about')
        listings_url = reverse('btre:listings')
        self.assertContains(self.response, 'href="{0}"'.format(index_url))
        self.assertContains(self.response, 'href="{0}"'.format(btre_index_url))
        self.assertContains(self.response, 'href="{0}"'.format(about_url))
        self.assertContains(self.response, 'href="{0}"'.format(listings_url))

    def test_navbar_links_exists_not_authenticated_user(self):
        signup_url = reverse('signup')
        login_url = reverse('login')
        self.assertContains(self.response, 'href="{0}"'.format(signup_url))
        self.assertContains(self.response, 'href="{0}"'.format(login_url))

    def test_navbar_links_exists_authenticated_user(self):
        user = User.objects.create_user(username='susiesalmon', password='abc123', email='ss@gmail.com', first_name='Susie', last_name='Salmon')
        self.client.login(username='susiesalmon', password='abc123')
        my_account_url = reverse('my_account')
        logout_url = reverse('logout')
        dashboard_url = reverse('btre:dashboard')
        url = reverse('btre:index')
        response = self.client.get(url)
        self.assertTrue(User.objects.exists())
        self.assertTrue(user.is_authenticated)
        self.assertContains(response, 'href="{0}"'.format(dashboard_url))
        self.assertContains(response, 'href="{0}"'.format(my_account_url))
        self.assertContains(response, 'href="{0}"'.format(logout_url))