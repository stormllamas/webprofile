from django.test import TestCase
from django.urls import reverse, resolve
from django.utils import timezone
import datetime

from ..models import Realtor, Listing
from ..views import about
from ..forms import SearchForm, ContactForm

from django.contrib.auth.models import User

from PIL import Image
import tempfile
from django.test import override_settings

def create_image(storage, filename, size=(100, 100), image_mode='RGB', image_format='PNG'):
    """
    Generate a test image, returning the filename that it was saved as.

    If ``storage`` is ``None``, the BytesIO containing the image data
    will be passed instead.
    """
    data = BytesIO()
    Image.new(image_mode, size).save(data, image_format)
    data.seek(0)
    if not storage:
        return data
    image_file = ContentFile(data.read())
    return storage.save(filename, image_file)

def create_realtor(name, photo, is_mvp):
    return Realtor.objects.create(name=name, photo=photo, is_mvp=is_mvp)

def create_listing(title, address, city, state, zipcode, price, bedrooms, bathrooms, garage, sqft, lot_size, realtor_num, photo_main):
    realtor = Realtor.objects.get(pk=realtor_num)
    return Listing.objects.create(title=title, address=address, realtor=realtor, city=city, state=state, zipcode=zipcode, price=price, bedrooms=bedrooms, bathrooms=bathrooms, garage=garage, sqft=sqft, lot_size=lot_size, photo_main=photo_main)

def get_temporary_image(temp_file):
    size = (200, 200)
    color = (255, 0, 0, 0)
    image = Image.new("RGB", size, color)
    image.save(temp_file, 'jpeg')
    return temp_file

class RealestateAboutViewTest(TestCase):
    def setUp(self):
        url = reverse('btre:about')
        self.response = self.client.get(url)

    def test_index_status_code(self):
        self.assertEquals(self.response.status_code, 200)

    def test_index_url_resolves_index_view(self):
        view = resolve('/realestate/about')
        self.assertEqual(view.func, about)
    
    def test_breadcrumb_links(self):
        btre_index_url = reverse('btre:index')
        self.assertContains(self.response, 'href="{0}"'.format(btre_index_url))

    def test_has_mvp(self):
        #create temporary file
        temp_file = tempfile.NamedTemporaryFile()
        realtor_image = get_temporary_image(temp_file)
        create_realtor(name='realtor_sample', photo=realtor_image.name, is_mvp=True)
        btre_listings_url = reverse('btre:listings')
        btre_about_url = reverse('btre:about')
        response = self.client.get(btre_about_url)
        self.assertTrue(Realtor.objects.exists())
        self.assertQuerysetEqual(response.context['mvp_realtors'], ['<Realtor: realtor_sample>'])
        self.assertContains(response, 'href="{0}"'.format(btre_listings_url))
        self.assertContains(response, 'realtor_sample')

    def test_no_mvp(self):
        #create temporary file
        temp_file = tempfile.NamedTemporaryFile()
        realtor_image = get_temporary_image(temp_file)
        create_realtor(name='realtor_sample', photo=realtor_image.name, is_mvp=False)
        btre_about_url = reverse('btre:about')
        response = self.client.get(btre_about_url)
        self.assertQuerysetEqual(response.context['mvp_realtors'], [])