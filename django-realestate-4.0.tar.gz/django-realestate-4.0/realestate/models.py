from django.db import models
from django.utils import timezone

import sys
from PIL import Image
from io import BytesIO
from django.core.files import File
from django.core.files.uploadedfile import InMemoryUploadedFile

def compress(image):
    im = Image.open(image)
    im_io = BytesIO() 
    im.save(im_io, 'JPEG', quality=20, optimize=True)
    new_photo_main = File(im_io, name=image.name)
    return new_photo_main
    # new_photo_main = InMemoryUploadedFile(im_io,'ImageField', "%s.jpg" % image.name.split('.')[0], 'image/jpeg', sys.getsizeof(im_io), None)
    # return new_photo_main

class Realtor(models.Model):
    name = models.CharField(max_length=200)
    photo = models.ImageField(upload_to='photos/%Y/%m/%d/')
    description = models.TextField(blank=True)
    phone = models.CharField(max_length=20)
    email = models.CharField(max_length=50)
    is_mvp = models.BooleanField(default=False)
    hire_date = models.DateTimeField(default=timezone.now, blank=True)
    
    def __str__(self):
        return self.name

class Listing(models.Model):
    realtor = models.ForeignKey(Realtor, on_delete=models.DO_NOTHING)
    title = models.CharField(max_length=200)
    address = models.CharField(max_length=200)
    city = models.CharField(max_length=200)
    state = models.CharField(max_length=200)
    zipcode = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    price = models.IntegerField()
    bedrooms = models.IntegerField()
    bathrooms = models.DecimalField(max_digits=2, decimal_places=1)
    garage = models.IntegerField(default=0)
    sqft = models.IntegerField()
    lot_size = models.DecimalField(max_digits=5, decimal_places=1)
    photo_main = models.ImageField(upload_to='photos/%Y/%m/%d/')
    photo_1 = models.ImageField(upload_to='photos/%Y/%m/%d/', blank=True)
    photo_2 = models.ImageField(upload_to='photos/%Y/%m/%d/', blank=True)
    photo_3 = models.ImageField(upload_to='photos/%Y/%m/%d/', blank=True)
    photo_4 = models.ImageField(upload_to='photos/%Y/%m/%d/', blank=True)
    photo_5 = models.ImageField(upload_to='photos/%Y/%m/%d/', blank=True)
    photo_6 = models.ImageField(upload_to='photos/%Y/%m/%d/', blank=True)
    is_published = models.BooleanField(default=True)
    list_date = models.DateTimeField(default=timezone.now, blank=True)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        new_image = compress(self.photo_main)
        self.photo_main = new_image
        super().save(*args, **kwargs)
        # if not self.id:
        #     self.photo_main = self.CompressImage(self.photo_main)
        #     self.photo_1 = self.CompressImage(self.photo_1)
        #     self.photo_2 = self.CompressImage(self.photo_2)
        #     self.photo_3 = self.CompressImage(self.photo_3)
        #     self.photo_4 = self.CompressImage(self.photo_4)
        #     self.photo_5 = self.CompressImage(self.photo_5)
        #     self.photo_6 = self.CompressImage(self.photo_6)
        # super(Listing, self).save(*args, **kwargs)

    # def CompressImage(self, photo_main):
    #     imageTemporary = Image.open(photo_main)
    #     outputIoStream = BytesIO()
    #     imageTemporaryResized = imageTemporary.resize( (1020,573) )
    #     imageTemporary.save(outputIoStream, format='JPEG', quality=60, optiimize=True)
    #     outputIoStream.seek(0)
    #     photo_main = InMemoryUploadedFile(outputIoStream, 'ImageField', "%s.jpg" % photo_main.name.split('.')[0], 'image/jpeg', sys.getsizeof(outputIoStream), None)
    #     return photo_main

class Contact(models.Model):
    listing = models.CharField(max_length=200)
    listing_id = models.IntegerField()
    name = models.CharField(max_length=200)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=100, blank=True, null=True)
    message = models.TextField(blank=True)
    contact_date = models.DateTimeField(default=timezone.now, blank=True)
    user_id = models.IntegerField(blank=True, null=True)

    def __str__(self):
        return self.name