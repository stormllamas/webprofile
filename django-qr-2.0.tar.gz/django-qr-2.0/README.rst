=====
Polls
=====

Django-QR is a simple Django app by Storm Llamas.

It can generate QR codes, scan them, put values,
or remove values from them. you will also see their
activity logs

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add these to your INSTALLED_APPS settings:

    INSTALLED_APPS = [
        'widget_tweaks',
        'qrcode',
        'attendees',
    ]

2. Include the URLconf in your project urls.py like this:

    path('qr/', include('attendees.urls'))

3. Run `python manage.py migrate` to create the qr models.

4. To edit models in admin include: "Attendee" and "ActivityLog"
   -See docs for admin.py script-