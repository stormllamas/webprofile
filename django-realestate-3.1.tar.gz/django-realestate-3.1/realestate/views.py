from django.shortcuts import render, redirect, get_object_or_404, reverse
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator

from realestate.choices import price_choices, bedroom_choices, state_choices

from .models import Listing, Realtor, Contact

from django.core.mail import send_mail
from django.contrib import messages

from .forms import ContactForm, SearchForm

def index(request):
    listings = Listing.objects.order_by('-list_date').filter(is_published=True)[:3]
    form = SearchForm()
    
    context = {
        'listings': listings,
        'form': form
    }

    return render(request, 'realestate/pages/index.html', context)

def about(request):
    realtors = Realtor.objects.order_by('hire_date')
    mvp_realtors = Realtor.objects.all().filter(is_mvp=True)
    
    context = {
        'realtors': realtors,
        'mvp_realtors': mvp_realtors
    }
    return render(request, 'realestate/pages/about.html', context)

def listings(request):
    listings = Listing.objects.order_by('-list_date').filter(is_published=True)
    paginator = Paginator(listings, 6)
    page = request.GET.get('realestate/page', 1)
    paged_listings = paginator.page(page)

    context = {
        'listings': paged_listings,
    }
    return render(request, 'realestate/listings/listings.html', context)

def listing(request, listing_id):
    listing = get_object_or_404(Listing, pk=listing_id)
    if request.method == 'POST':
        form = ContactForm(request.POST)
        print('------------------------request is post------------------------')
        if request.user.is_authenticated:
            user_id = request.user.id
            has_contacted = Contact.objects.all().filter(listing_id=listing_id, user_id = user_id)
            if has_contacted:
                messages.error(request, 'You have already made an inquiry for this listing')
                return redirect(reverse('btre:listing', kwargs={'listing_id': listing.id}))

        if form.is_valid():
            print('------------------------form is valid------------------------')
            contact = form.save(commit=False)
            contact.user_id = request.user.id
            contact.listing_id = listing.id
            contact.realtor_email = listing.realtor.email
            contact.save()

            messages.success(request, 'Your request has been submitted, a realtor will get back to you soon')

            return redirect(reverse('btre:listing', kwargs={'listing_id': listing.id}))

        # else:
        #     messages.error(request, 'Invalid Form. Please check inquiry')


    else:
        if request.user.is_authenticated:
            form = ContactForm(
                initial={
                    'listing': listing.title,
                    'name': request.user.first_name+' '+request.user.last_name,
                    'email': request.user.email
                    }
                )
        else:
            form = ContactForm(
                initial={
                    'listing': listing.title,
                    }
                )

    return render(request, 'realestate/listings/listing.html', {'listing': listing, 'form':form})

# class SearchListView(ListView):
#     model = Listing
#     context_object_name = 'listings'
#     template_name = 'listings/search.html'

#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         context['']



def search(request):
    queryset_list = Listing.objects.order_by('-list_date').filter(is_published=True)

    if request.method == "POST":
        form = SearchForm(request.POST)
        print('------------------------request is post------------------------')
        if form.is_valid():
            keywords = form.cleaned_data.get('keywords')
            city = form.cleaned_data.get('city')
            state = form.cleaned_data.get('state')
            bedrooms = form.cleaned_data.get('bedrooms')
            max_price = form.cleaned_data.get('max_price')
        
            # initial={
            #     'listing': listing.title,
            #     'name': request.user.first_name+' '+request.user.last_name,
            #     'email': request.user.email
            #     }

        if keywords:
            queryset_list = queryset_list.filter(description__icontains=keywords)

        if city:
            queryset_list = queryset_list.filter(city__iexact=city)
        
        if state:
            queryset_list = queryset_list.filter(state__iexact=state)

        if bedrooms:
            queryset_list = queryset_list.filter(bedrooms__lte=bedrooms)

        if max_price:
            queryset_list = queryset_list.filter(price__lte=max_price)

        context = {
            'listings': queryset_list,
            'form': form,
            }

        return render(request, 'realestate/listings/search.html', context)

    else:
        print('------------------------request is not post------------------------')
        context = {
            'form': form,
            'listings': listings,
            }
    
    return render(request, 'realestate/listings/search.html', context)

def contact(request):
  if request.method == 'POST':
    listing_id = request.POST['listing_id']
    listing = request.POST['listing']
    name = request.POST['name']
    email = request.POST['email']
    phone = request.POST['phone']
    message = request.POST['message']
    user_id = request.POST['user_id']
    realtor_email = request.POST['realtor_email']

    #  Check if user has made inquiry already
    if request.user.is_authenticated:
      user_id = request.user.id
      has_contacted = Contact.objects.all().filter(listing_id=listing_id, user_id=user_id)
      if has_contacted:
        messages.error(request, 'You have already made an inquiry for this listing')
        return redirect('/realestate/listing/'+listing_id)

    contact = Contact(listing=listing, listing_id=listing_id, name=name, email=email, phone=phone, message=message, user_id=user_id )

    contact.save()

    # Send email
    # send_mail(
    #   'Property Listing Inquiry',
    #   'There has been an inquiry for ' + listing + '. Sign into the admin panel for more info',
    #   'traversy.brad@gmail.com',
    #   [realtor_email, 'stormsiallamas@gmail.com'],
    #   fail_silently=False
    # )

    messages.success(request, 'Your request has been submitted, a realtor will get back to you soon')
    return redirect('/realestate/listing/'+listing_id)

def dashboard(request):
    user_contacts = Contact.objects.order_by('-contact_date').filter(user_id=request.user.id)
    context = {
        'contacts': user_contacts,
    }
    return render(request, 'realestate/pages/dashboard.html', context)